import { Component, System } from '@/types/domain';
function safeEval(expr:string,vars:Record<string,number>){
  const normalized=expr.replace(/\bwidth\b/g,'w').replace(/\bheight\b/g,'h').replace(/\bquantity\b/g,'q');
  if(!/^[0-9+\-*/(). _whq]+$/.test(normalized)) throw new Error('Formula inválida');
  const fn=new Function('w','h','q',`return (${normalized})`); return Number(fn(vars.width,vars.height,vars.quantity));
}
export function calculateSystem(system:System,width:number,height:number,quantity=1){
  return system.components.map((c:Component)=>{const length=safeEval(c.formula??'0',{width,height,quantity});const qty=safeEval(c.quantityFormula??'1',{width,height,quantity});const total=length*c.price*qty*quantity;return {component:c,measure:length,quantity:qty*quantity,total};});
}
export function calculateQuote(items:{system:System;width:number;height:number;quantity:number}[],marginRate:number,taxRate:number){
 const base=items.flatMap(i=>calculateSystem(i.system,i.width,i.height,i.quantity)); const cost=base.reduce((s,x)=>s+x.total,0); const margin=cost*(marginRate/100); const subtotal=cost+margin; const tax=subtotal*(taxRate/100); return {lines:base,cost,margin,subtotal,tax,total:subtotal+tax};
}
