export function money(value:number,currency:string){return new Intl.NumberFormat(undefined,{style:'currency',currency:currency==='CUSTOM'?'USD':currency,maximumFractionDigits:2}).format(value)}
export function fmtDate(value:string){return new Intl.DateTimeFormat('es-MX',{dateStyle:'medium'}).format(new Date(value))}
