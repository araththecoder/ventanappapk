import { Brand, Company, System } from '@/types/domain';
export const company:Company={id:'demo-company',name:'Mi Empresa',currency:'MXN',measurementUnit:'mm',taxName:'IVA',taxRate:16,marginRate:35};
export const brands:Brand[]=[{id:'brand-1',name:'Marca Demo'}];
export const systems:System[]=[
{id:'sys-fixed',brandId:'brand-1',name:'Fija',windowType:'fixed',components:[
{id:'c-frame',name:'Marco perimetral',type:'profile',unit:'mm',price:120,formula:'width',quantityFormula:'2'},
{id:'c-frame-v',name:'Marco vertical',type:'profile',unit:'mm',price:120,formula:'height',quantityFormula:'2'},
{id:'c-glass',name:'Cristal',type:'glass',unit:'m2',price:850,formula:'(width*height)/1000000',quantityFormula:'1'},
{id:'c-seal',name:'Empaque / sello',type:'seal',unit:'mm',price:1.8,formula:'2*(width+height)',quantityFormula:'1'}],formulas:[]},
{id:'sys-proj',brandId:'brand-1',name:'Proyección',windowType:'projection',components:[
{id:'p-frame',name:'Marco perimetral',type:'profile',unit:'mm',price:120,formula:'2*(width+height)',quantityFormula:'1'},
{id:'p-sash',name:'Hoja',type:'profile',unit:'mm',price:125,formula:'2*((width-40)+(height-40))',quantityFormula:'1'},
{id:'p-glass',name:'Cristal',type:'glass',unit:'m2',price:850,formula:'((width-40)*(height-40))/1000000',quantityFormula:'1'},
{id:'p-hardware',name:'Herraje',type:'hardware',unit:'unit',price:280,formula:'1',quantityFormula:'1'}],formulas:[]},
{id:'sys-slide',brandId:'brand-1',name:'Corrediza 2 hojas',windowType:'sliding',components:[
{id:'s-frame',name:'Marco perimetral',type:'profile',unit:'mm',price:120,formula:'2*(width+height)',quantityFormula:'1'},
{id:'s-leaves',name:'Hojas corredizas',type:'profile',unit:'mm',price:125,formula:'2*(((width/2)+20)+(height-40))',quantityFormula:'2'},
{id:'s-glass',name:'Cristal',type:'glass',unit:'m2',price:850,formula:'(((width/2)-20)*(height-40))/1000000',quantityFormula:'2'},
{id:'s-rollers',name:'Carretillas',type:'hardware',unit:'unit',price:75,formula:'1',quantityFormula:'4'},
{id:'s-lock',name:'Cierre',type:'hardware',unit:'unit',price:180,formula:'1',quantityFormula:'1'}],formulas:[]}
];
