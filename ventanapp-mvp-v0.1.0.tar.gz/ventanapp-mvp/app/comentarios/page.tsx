export default function Comentarios(){return <div><h1 className="text-3xl font-black">Comentarios</h1><p className="mt-2 text-slate-500">Módulo de feedback para la evolución del producto.</p></div>}
