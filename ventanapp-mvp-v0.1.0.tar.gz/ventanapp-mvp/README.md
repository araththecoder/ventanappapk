# VentanApp MVP

VentanApp es un motor de cotización y despiece configurable para ventanas y puertas. Está diseñado desde el inicio como producto multiempresa: cada empresa puede definir sus propias marcas, líneas, sistemas, componentes, precios, fórmulas, moneda, impuestos y plantilla de cotización.

## MVP incluido
- Dashboard tipo mosaico inspirado en el flujo operativo de software profesional de ventanería.
- Nueva orden con cliente, sistema, ancho, alto y cantidad.
- Sistemas demo: Fija, Proyección y Corrediza 2 hojas.
- Vista técnica básica que cambia según el tipo de sistema.
- Motor de fórmulas separado del catálogo.
- Despiece y cálculo de costos.
- Margen e impuesto configurables en el modelo de dominio.
- Catálogo de componentes y precios.
- Arquitectura de base de datos Supabase lista para migración.
- Unidades: únicamente mm e in.
- Moneda configurable: MXN, USD, EUR, GBP o personalizada.
- Preparación para historial de cotizaciones, snapshot de precios, pedidos y archivos.

## Stack
Next.js 15 · React 19 · TypeScript · Tailwind CSS · Supabase · Vercel

## Ejecutar localmente
```bash
npm install
npm run dev
```

Después abre `http://localhost:3000`.

## Variables de entorno
Copia `.env.example` a `.env.local` y agrega las credenciales de tu proyecto Supabase cuando se conecte la base real.

## Supabase
La primera migración está en `supabase/migrations/0001_initial.sql`.

## Arquitectura de cálculo
No se pretende que cada marca tenga código propio. La relación es:

`Sistema → Componente → Fórmula → Medidas → Resultado → Costo`

Esto permite que una empresa agregue sus propias reglas sin modificar el motor central.

**Importante:** el MVP usa un evaluador de expresiones sencillo para demostración. Antes de producción debe reemplazarse por un parser seguro/DSL de fórmulas, validación de variables y límites de ejecución; nunca se debe permitir ejecutar JavaScript arbitrario introducido por una empresa.

## Próxima fase
1. Supabase Auth + multiempresa/RLS.
2. CRUD de marcas, líneas, sistemas y componentes.
3. Editor de fórmulas seguro.
4. Editor de configuraciones de ventanas.
5. Snapshot de precios al guardar cotización.
6. Generación de PDF con plantilla configurable.
7. Archivos y adjuntos por orden.
8. Estados de pedido y seguimiento.
9. PWA/offline y empaquetado Android.
10. Distribución internacional.
