import type { Config } from 'tailwindcss';
export default { content: ['./app/**/*.{ts,tsx}','./components/**/*.{ts,tsx}'], theme: { extend: { colors: { ink:'#10243e', navy:'#0b3156', blue:'#1266a8', sky:'#eaf4fb', line:'#d8e2eb' }, boxShadow:{soft:'0 10px 30px rgba(15,45,75,.08)'} } }, plugins: [] } satisfies Config;
